module.exports = {
  dbURL: 'mongodb://test:test@ds159489.mlab.com:59489/ecom'
};
